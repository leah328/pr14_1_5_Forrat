﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace prakt_14
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stack<int> st = new Stack<int>();
            st.Clear();
            if (textBox1.Text != "")
            {
                int n = Convert.ToInt32(textBox1.Text);
                for (int i = 1; i <= n; i++)
                {
                    st.Push(i);
                }

            }
            else MessageBox.Show("поле пустое, введите число!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            if (st.Count > 0)
            {
                listBox1.Items.Add($"n={textBox1.Text}");
                listBox1.Items.Add($"Размерность стека {st.Count}");
                listBox1.Items.Add($"Верхний элемент стека:{st.Peek()}");
                listBox1.Items.Add($"Содержимое стека:{string.Join(" ", st)}");
                st.Clear();
                listBox1.Items.Add($"Новая размерность стека:{st.Count}");
            }
            else MessageBox.Show("стек пустой", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Queue<Person> people = new Queue<Person>();
            string file = "1.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("файл не найден", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] s = File.ReadAllLines(file);

                Person p1 = new Person("", "", "", 0, 0.0);

                foreach (string ss in s)
                {
                    string[] peopl = ss.Split(' ');
                    string fam = peopl[0];
                    p1.set_lastname(fam);
                    string name = peopl[1];
                    p1.set_name(name);
                    string ot = peopl[2];
                    p1.set_otfather(ot);
                    int age = Convert.ToInt32(peopl[3]);
                    p1.set_age(age);
                    double weith = Convert.ToDouble(peopl[4]);
                    p1.set_weidth(weith);
                    listBox3.Items.Add($"{p1.get_lastname()} {p1.get_name()} {p1.get_otfather()}, Возраст: {p1.get_age()} лет, Вес:{p1.get_weidth()} кг");
                    people.Enqueue(new Person(fam, name, ot, age, weith));
                }
                var yung = from p in people
                           where Convert.ToInt32(p.get_age()) < 40
                           select p;

                foreach (var y in yung)
                {
                    listBox2.Items.Add($"{y.get_lastname()} {y.get_name()} {y.get_otfather()}, Возраст: {y.get_age()} лет, Вес: {y.get_weidth()} кг");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Queue<int> qu = new Queue<int>();
            qu.Clear();
            if (textBox2.Text != "")
            {
                int n = Convert.ToInt32(textBox2.Text);
                for (int i = 1; i <= n; i++)
                {
                    qu.Enqueue(i);
                }

            }
            else MessageBox.Show("поле пустое, введите число!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            if (qu.Count > 0)
            {
                listBox4.Items.Add($"n={textBox2.Text}");
                listBox4.Items.Add($"Размерность очереди {qu.Count}");
                listBox4.Items.Add($"Верхний элемент стека:{string.Join(" ", qu)}");
                qu.Clear();
                listBox4.Items.Add($"Новая размерность очереди:{qu.Count}");
            }
            else MessageBox.Show("очередь пустая", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            bool b = true;
            int c = 0, cc = 0;
            Stack<char> stack = new Stack<char>();
            try
            {
                if (textBox3.Text != "")
                {
                    string s = textBox3.Text;
                    for (int i = 0; i < s.Length; i++)
                    {
                        stack.Push(s[i]);
                        char k = s[i];
                        if (stack.Peek() != '0' && stack.Peek() != '1' && stack.Peek() != '2' && stack.Peek() != '3' &&
                            stack.Peek() != '4' && stack.Peek() != '5' && stack.Peek() != '6' && stack.Peek() != '7' &&
                            stack.Peek() != '8' && stack.Peek() != '9' && stack.Peek() != '/' && stack.Peek() != '*' &&
                            stack.Peek() != '-' && stack.Peek() != '+' && stack.Peek() != '.' && stack.Peek() != ')' &&
                            stack.Peek() != '(') ;
                        b = false;
                        if (stack.Peek() == ')') c++;
                        if (stack.Peek() == '(') cc++;
                    }
                    if (b == true && c == cc)
                    {
                        listBox5.Items.Add("скобки сбалансированы");
                        listBox5.Items.Add(s);
                        StreamWriter sw = File.CreateText("new.txt");
                        sw.WriteLine(s);
                        sw.Close();
                    }
                    else if (c > cc)
                    {
                        listBox5.Items.Add($"возможно лишняя ) скобка на позиции: {s.IndexOf("(")}");
                    }
                    else if (c < cc)
                    {
                        listBox5.Items.Add($"возможно лишняя ( скобка на позиции: {s.IndexOf(")")}");
                    }
                }
            }
            catch (FormatException) { MessageBox.Show("ошибка", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); }


        }

        private void button5_Click(object sender, EventArgs e)
        {
            Queue<Person> p51 = new Queue<Person>();
            Queue<Person> p52 = new Queue<Person>();
            string file1 = "51.txt";
            string file2 = "52.txt";
            if (!File.Exists(file1) && !File.Exists(file2))
            {
                MessageBox.Show("файл не найден", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] s1 = File.ReadAllLines(file1);
                Person pp = new Person("", "", "", 0, 0.0);

                foreach (string ss in s1)
                {
                    string[] peopl = ss.Split(' ');
                    string fam = peopl[0];
                    pp.set_lastname(fam);
                    string name = peopl[1];
                    pp.set_name(name);
                    string ot = peopl[2];
                    pp.set_otfather(ot);
                    int age = 0;
                    pp.set_age(age);
                    double weith = 0;
                    pp.set_weidth(weith);
                    listBox7.Items.Add($"{pp.get_lastname()} {pp.get_name()} {pp.get_otfather()}, Возраст: {pp.get_age()} лет, Вес:{pp.get_weidth()} кг");
                    p51.Enqueue(new Person(fam, name, ot, age, weith));


                    /*     int age = Convert.ToInt32(peopl[3]);
                         p1.set_age(age);
                         double weith = Convert.ToDouble(peopl[4]);
                         p1.set_weidth(weith);*/
                    /*     listBox3.Items.Add($"{p1.get_lastname()} {p1.get_name()} {p1.get_otfather()}, Возраст: {p1.get_age()} лет, Вес:{p1.get_weidth()} кг");*/

                }
                /*   var yung = from p in people
                              where Convert.ToInt32(p.get_age()) < 40
                              select p;

                   foreach (var y in yung)
                   {
                       listBox2.Items.Add($"{y.get_lastname()} {y.get_name()} {y.get_otfather()}, Возраст: {y.get_age()} лет, Вес: {y.get_weidth()} кг");
                   }*/
                string[] s2 = File.ReadAllLines(file2);
                Person p1 = new Person("", "", "", 0, 0.0);
                foreach (string ss1 in s2)
                {
                    string[] peopl1 = ss1.Split(' ');
                    string fam = "";
                    pp.set_lastname(fam);
                    string name = "";
                    pp.set_name(name);
                    string ot = "";
                    pp.set_otfather(ot);
                    int age = Convert.ToInt32(peopl1[0]);
                    pp.set_age(age);
                    double weith = Convert.ToDouble(peopl1[1]);
                    pp.set_weidth(weith);
                    listBox7.Items.Add($"{pp.get_lastname()} {pp.get_name()} {pp.get_otfather()}, Возраст: {pp.get_age()} лет, Вес:{pp.get_weidth()} кг");
                    p52.Enqueue(new Person(fam, name, ot, age, weith));
                }

             /*   var result = p51.Join(p52, p=>p.pp,t=>t.);*/

                }
            }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
