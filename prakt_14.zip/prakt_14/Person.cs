﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prakt_14
{
    class Person
    {

        private string fam;
        private string name;
        private string ot;
        private int age;
        private double weith;

        public Person(string fam, string name, string ot, int age, double weith)
        {
            this.fam = fam;
            this.name = name;
            this.ot = ot;
            this.age = age;
            this.weith = weith;
        }
        public void set_lastname(string f)
        {
            this.fam = f;
        }
        public string get_lastname()
        {
            return this.fam;
        }
        public void set_name(string f)
        {
            this.name = f;
        }
        public string get_name()
        {
            return this.name;
        }
        public void set_otfather(string f)
        {
            this.ot = f;
        }
        public string get_otfather()
        {
            return this.ot;
        }
        public void set_age(int f)
        {
            this.age = f;
        }
        public int get_age()
        {
            return this.age;
        }
        public void set_weidth(double f)
        {
            this.weith = f;
        }
        public double get_weidth()
        {
            return this.weith;
        }
    }
}
